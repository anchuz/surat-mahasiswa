<?php

class Prodi extends Eloquent {

	protected $table = 'tbprodi'; //mengambil nama tabel yang tidak sama dengan nama model

}