<?php

class Jabatan extends Eloquent {

	protected $table = 'tbjabatans'; //mengambil nama tabel yang tidak sama dengan nama model

}