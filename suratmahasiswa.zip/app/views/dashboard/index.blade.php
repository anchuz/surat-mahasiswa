@section('title')
	{{ $title }}
@stop

@section('breadcrumb')
	<li><a href="dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
@stop

@section('content')	
	Selamat Datang di Dashboard Aplikasi Surat Mahasiswa
@stop