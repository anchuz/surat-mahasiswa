<link rel="stylesheet" href="{{ asset('packages/select2/select2.css')}}" />
<script src="{{ asset('packages/select2/select2.min.js')}}"></script>
<script src="{{ asset('packages/select2/select2_locale_id.js')}}"></script>